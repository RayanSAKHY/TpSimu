package ISIMA.F2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimuLapinApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimuLapinApplication.class, args);
	}

}
